import { Link, useNavigate } from "react-router";
import { Car, Menu, User, Crown } from "lucide-react";
import { Button } from "./ui/button";
import { Sheet, SheetContent, SheetTrigger } from "./ui/sheet";

export function Header() {
  const navigate = useNavigate();

  const NavLinks = () => (
    <>
      <Link to="/" className="text-sm hover:text-primary transition-colors">
        Rechercher
      </Link>
      <Link to="/publish" className="text-sm hover:text-primary transition-colors">
        Publier un trajet
      </Link>
      <Link to="/dashboard" className="text-sm hover:text-primary transition-colors">
        Mes trajets
      </Link>
      <Link to="/premium" className="text-sm hover:text-primary transition-colors flex items-center gap-1">
        <Crown className="size-4 text-yellow-500" />
        Premium
      </Link>
    </>
  );

  return (
    <header className="border-b bg-white sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="bg-primary text-white p-2 rounded-lg">
            <Car className="size-6" />
          </div>
          <span className="text-2xl font-bold text-primary">Wassalni</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <NavLinks />
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <Button variant="ghost" size="sm">
            <User className="size-4 mr-2" />
            Connexion
          </Button>
          <Button size="sm">S'inscrire</Button>
        </div>

        {/* Mobile Navigation */}
        <Sheet>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="size-6" />
            </Button>
          </SheetTrigger>
          <SheetContent>
            <div className="flex flex-col gap-6 mt-8">
              <NavLinks />
              <div className="flex flex-col gap-3 pt-6 border-t">
                <Button variant="outline">
                  <User className="size-4 mr-2" />
                  Connexion
                </Button>
                <Button>S'inscrire</Button>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
