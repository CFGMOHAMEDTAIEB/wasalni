import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { SearchResults } from "./pages/SearchResults";
import { RideDetails } from "./pages/RideDetails";
import { PublishRide } from "./pages/PublishRide";
import { Dashboard } from "./pages/Dashboard";
import { Premium } from "./pages/Premium";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/search",
    Component: SearchResults,
  },
  {
    path: "/ride/:id",
    Component: RideDetails,
  },
  {
    path: "/publish",
    Component: PublishRide,
  },
  {
    path: "/dashboard",
    Component: Dashboard,
  },
  {
    path: "/premium",
    Component: Premium,
  },
]);
