import { useState } from "react";
import { Header } from "../components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import {
  Car,
  Users,
  DollarSign,
  Calendar,
  MapPin,
  Crown,
  TrendingUp,
  BadgeCheck,
} from "lucide-react";
import { mockRides } from "../data/mockData";

export function Dashboard() {
  const [activeTab, setActiveTab] = useState("rides");

  // Mock user data
  const userRides = mockRides.slice(0, 2);
  const userBookings = mockRides.slice(2, 4);

  const totalEarnings = userRides.reduce((sum, ride) => {
    const commission = ride.driver.premium ? ride.price * 0.05 : ride.price * 0.1;
    const bookedSeats = ride.totalSeats - ride.seatsAvailable;
    return sum + ride.price * bookedSeats - commission * bookedSeats;
  }, 0);

  const totalCommissions = userRides.reduce((sum, ride) => {
    const commission = ride.driver.premium ? ride.price * 0.05 : ride.price * 0.1;
    const bookedSeats = ride.totalSeats - ride.seatsAvailable;
    return sum + commission * bookedSeats;
  }, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Mon Tableau de Bord</h1>
          <p className="text-muted-foreground">
            Gérez vos trajets et réservations
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Trajets publiés</p>
                  <p className="text-2xl font-bold">{userRides.length}</p>
                </div>
                <Car className="size-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Réservations</p>
                  <p className="text-2xl font-bold">{userBookings.length}</p>
                </div>
                <Users className="size-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Gains totaux</p>
                  <p className="text-2xl font-bold">{totalEarnings.toFixed(0)} DT</p>
                </div>
                <DollarSign className="size-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Commissions payées
                  </p>
                  <p className="text-2xl font-bold">
                    {totalCommissions.toFixed(0)} DT
                  </p>
                </div>
                <TrendingUp className="size-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Premium Banner */}
        <Card className="mb-8 bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-300">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Crown className="size-12 text-yellow-600" />
                <div>
                  <h3 className="font-bold text-lg mb-1">
                    Passez à Premium et économisez !
                  </h3>
                  <p className="text-sm text-gray-700">
                    Réduisez les frais de service à 5% et bénéficiez de la mise en
                    vedette gratuite
                  </p>
                </div>
              </div>
              <Button className="bg-yellow-600 hover:bg-yellow-700">
                Découvrir Premium
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="rides">Mes trajets</TabsTrigger>
            <TabsTrigger value="bookings">Mes réservations</TabsTrigger>
            <TabsTrigger value="earnings">Revenus</TabsTrigger>
          </TabsList>

          <TabsContent value="rides" className="space-y-4">
            {userRides.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Car className="size-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-lg text-muted-foreground mb-4">
                    Vous n'avez pas encore publié de trajet
                  </p>
                  <Button>Publier mon premier trajet</Button>
                </CardContent>
              </Card>
            ) : (
              userRides.map((ride) => (
                <Card key={ride.id}>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-bold text-lg">
                            {ride.from} → {ride.to}
                          </h3>
                          {ride.featured && (
                            <Badge className="bg-yellow-500">
                              <Crown className="size-3 mr-1" />
                              Vedette
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="size-4" />
                            {new Date(ride.date).toLocaleDateString("fr-FR")}
                          </span>
                          <span>{ride.time}</span>
                          <span className="flex items-center gap-1">
                            <Users className="size-4" />
                            {ride.totalSeats - ride.seatsAvailable}/
                            {ride.totalSeats} places réservées
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-primary">
                          {ride.price} DT
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Commission:{" "}
                          {(
                            ride.price *
                            (ride.driver.premium ? 0.05 : 0.1)
                          ).toFixed(2)}{" "}
                          DT
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Modifier
                      </Button>
                      <Button variant="outline" size="sm">
                        Annuler
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="bookings" className="space-y-4">
            {userBookings.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Users className="size-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-lg text-muted-foreground mb-4">
                    Vous n'avez pas encore de réservation
                  </p>
                  <Button>Rechercher un trajet</Button>
                </CardContent>
              </Card>
            ) : (
              userBookings.map((ride) => (
                <Card key={ride.id}>
                  <CardContent className="p-6">
                    <div className="flex gap-4">
                      <img
                        src={ride.driver.image}
                        alt={ride.driver.name}
                        className="w-16 h-16 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold">{ride.driver.name}</h3>
                          {ride.driver.verified && (
                            <BadgeCheck className="size-4 text-blue-500" />
                          )}
                        </div>
                        <p className="font-bold mb-1">
                          {ride.from} → {ride.to}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(ride.date).toLocaleDateString("fr-FR")} à{" "}
                          {ride.time}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold">{ride.price} DT</p>
                        <Badge className="mt-2">Confirmé</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="earnings">
            <Card>
              <CardHeader>
                <CardTitle>Résumé des revenus</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg">
                    <span className="font-medium">Total des gains</span>
                    <span className="text-2xl font-bold text-green-600">
                      {totalEarnings.toFixed(2)} DT
                    </span>
                  </div>

                  <div className="flex justify-between items-center p-4 bg-red-50 rounded-lg">
                    <span className="font-medium">Commissions payées (10%)</span>
                    <span className="text-2xl font-bold text-red-600">
                      -{totalCommissions.toFixed(2)} DT
                    </span>
                  </div>

                  <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
                    <span className="font-semibold text-lg">Revenu net</span>
                    <span className="text-3xl font-bold text-blue-600">
                      {(totalEarnings - totalCommissions).toFixed(2)} DT
                    </span>
                  </div>

                  <div className="pt-4 border-t">
                    <p className="text-sm text-muted-foreground mb-4">
                      💡 <strong>Astuce:</strong> Avec Premium, vous ne payez que
                      5% de commission au lieu de 10%. Vous auriez économisé{" "}
                      {(totalCommissions * 0.5).toFixed(2)} DT ce mois-ci !
                    </p>
                    <Button className="w-full">Passer à Premium</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
